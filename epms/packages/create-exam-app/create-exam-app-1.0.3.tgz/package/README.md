# create-exam-app

CLI to scaffold exam projects from npm. It prints **every template** in `templates/projects.json` with a short name, title, and one-line description. You pick a number (and optionally a folder name) and get:

- `backend/`
- `frontend/`
- `README.md`
- `.env` (project root) and `backend/.env` (from `backend/.env.example` when not already present)

## For users: `npx create-exam-app` — what the list is and what to choose

1. Run:

   ```bash
   npx create-exam-app
   ```

   (Optional first argument: folder name, e.g. `npx create-exam-app my-app` — you still get the same template picker if there is more than one project.)

2. The CLI shows **one block per line**, in order, for each template, for example:

   - `[1] EPMS — …` = **Employee Payroll Management** (departments, employees, salaries, payroll report).
   - `[2] SIMS — …` = **Stock Inventory (SWD Day 6)** (spare parts, stock in, stock out rules, daily reports).

3. **What to pick**

   - Choose **`1` / EPMS** if the exam is **payroll** (departments, employees, salary, monthly report).
   - Choose **`2` / SIMS** if the exam is **inventory** (spare parts, stock in, stock out, daily stock / stock-out reports).
   - Press **Enter** at the prompt to keep the default **`1`** (first in the list).

4. It then asks for a **project folder name** (default: `epms-app` or `sims-app` depending on the template). Use an empty name or Enter for the default.

5. **Ports after `npm run dev`**

   - **EPMS:** API `5000`, app `http://localhost:5173`
   - **SIMS:** API `5001`, app `http://localhost:5174`  
   (The final CLI message after scaffolding repeats these for the template you selected.)

6. In each of **backend** and **frontend**, run `npm install` then `npm run dev` (and ensure MongoDB matches `backend/.env`).

## Templates (manifest)

| Order | ID   | Name  | When to use |
|------:|------|-------|-------------|
| 1     | epms | EPMS  | Payroll, departments, employees, salary CRUD, monthly report |
| 2     | sims | SIMS  | Spare parts, stock in, stock out (out CRUD), daily stock reports |

The live list in the CLI is driven by `templates/projects.json` — add a `projects[]` entry and a matching `templates/<templateDir>/` folder to ship another exam.

## Maintainer: sync templates (required before pack/publish)

Package path: `exams-p/epms/packages/create-exam-app` (or your clone’s equivalent).

```bash
cd epms/packages/create-exam-app
npm run sync-all
npm run verify
```

- `sync-epms` — copies from `epms/backend` and `epms/frontend` into `templates/epms/`
- `sync-sims` — copies from `sims/backend` and `sims/frontend` into `templates/sims/` (expects `sims` next to `exams-p/epms` in the repo layout)

`prepack` runs `verify` so `npm pack` and `npm publish` **fail** if any `projects.json` entry has no `templates/<templateDir>` folder. Always run `sync-all` when sources change, then ship.

## Publish to npm (checklist)

1. `npm run sync-all` and `npm run verify`
2. Bump `version` in this folder’s `package.json` (semver)
3. `npm pack` and inspect the tarball, or `npm publish --dry-run`
4. `npm login` (scope registry if you use a scope)
5. `npm publish --access public`  
   (Use `--access public` for an unscoped name like `create-exam-app` so it is installable without scope.)

If publish fails in `prepack`, run `sync-all` and confirm `templates/sims` and `templates/epms` both exist with `backend/` and `frontend/`.

## License

MIT
