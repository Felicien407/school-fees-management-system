# create-exam-app

Scaffolds exam projects with `README.md` and `.env` files copied from examples.

## Users

```bash
npx create-exam-app
npx create-exam-app my-folder
```

- Pick a template from the numbered list.
- Output: **`Done: <path>`**

### National exam templates (SMS, SRMS, SCMS, EPMS)

Each scaffolds:

```
your-app/
├── frontend/           # React + Tailwind (port 6666)
├── backend-mysql/      # Express + mysql2 (port 5555)
└── backend-mongodb/    # Express + Mongoose (port 5555)
```

Run **one backend** at a time, then the frontend:

```bash
cd backend-mysql && npm install && npm run db:init && npm run dev
cd ../frontend && npm install && npm run dev
```

Or use `backend-mongodb` instead of `backend-mysql`.

Default login: `admin` / `admin123`

### Legacy templates (SIMS, LMS)

Use classic `backend/` + `frontend/` layout (unchanged).

## Templates (manifest)

| # | ID | Name | Layout |
|---|-----|------|--------|
| 1 | stockhub-sms | SMS | dual backend + frontend |
| 2 | srms | SRMS | dual backend + frontend |
| 3 | scms | SCMS | dual backend + frontend |
| 4 | epms | EPMS | dual backend + frontend |
| 5 | sims | SIMS | backend + frontend |
| 6 | lms | LMS | backend + frontend |

List is driven by `templates/projects.json`.

## Maintainer: sync before publish

```bash
cd epms/packages/create-exam-app
npm run sync-all
npm run verify
```

- `sync-national` — stockhub-sms, srms, scms, epms → `templates/<id>/`
- `sync-template` — refreshes `templates/epms/` from live `epms/`
- `sync-sims` / `sync-lms` — legacy projects (unchanged)

## License

MIT
