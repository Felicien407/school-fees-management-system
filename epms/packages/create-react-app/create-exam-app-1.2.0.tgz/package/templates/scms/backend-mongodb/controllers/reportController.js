const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const endOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);
const periodRange = (period) => {
  const now = new Date();
  if (period === "daily") return { $gte: startOfDay(now), $lte: endOfDay(now) };
  if (period === "weekly") {
    const day = now.getDay() || 7;
    const monday = new Date(now);
    monday.setDate(now.getDate() - day + 1);
    monday.setHours(0, 0, 0, 0);
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    sunday.setHours(23, 59, 59, 999);
    return { $gte: monday, $lte: sunday };
  }
  const first = new Date(now.getFullYear(), now.getMonth(), 1);
  const last = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
  return { $gte: first, $lte: last };
};
const clean = (rows) => rows.map((r) => { const { _id, __v, ...rest } = r; return rest; });

import Supplier from "../models/Supplier.js";
import Shipment from "../models/Shipment.js";
import Delivery from "../models/Delivery.js";

export const getReports = async (req, res) => {
  try {
    const period = req.query.period || "daily";
    const shipRange = periodRange(period);
    const delRange = periodRange(period);
    const suppliers = clean(await Supplier.find().lean());
    const shipments = clean(await Shipment.find({ shipment_date: shipRange }).lean());
    const deliveries = clean(await Delivery.find({ delivery_date: delRange }).lean());
    return res.json({ period, reports: { suppliers, shipments, deliveries } });
  } catch {
    return res.status(500).json({ message: "Failed to generate reports." });
  }
};
