import { query } from "../config/db.js";
export const getReports = async (req, res) => {
  try {
    const period = req.query.period || "daily";
    const ranges = { daily: "DATE(hired_date) = CURDATE()", weekly: "YEARWEEK(hired_date, 1) = YEARWEEK(CURDATE(), 1)", monthly: "YEAR(hired_date) = YEAR(CURDATE()) AND MONTH(hired_date) = MONTH(CURDATE())" };
    const empClause = ranges[period] || ranges.daily;
    const salRanges = { daily: "month_of_payment = DATE_FORMAT(CURDATE(), '%Y-%m')", weekly: "month_of_payment = DATE_FORMAT(CURDATE(), '%Y-%m')", monthly: "month_of_payment = DATE_FORMAT(CURDATE(), '%Y-%m')" };
    const employees = await query(`SELECT * FROM employees WHERE ${empClause}`);
    const departments = await query("SELECT * FROM departments");
    const salaries = await query(`SELECT * FROM salaries WHERE ${salRanges[period] || salRanges.monthly}`);
    return res.json({ period, reports: { employees, departments, salaries } });
  } catch { return res.status(500).json({ message: "Failed to generate reports." }); }
};