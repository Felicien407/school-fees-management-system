import { query } from "../config/db.js";

const ranges = {
  daily: "DATE({f}) = CURDATE()",
  weekly: "YEARWEEK({f}, 1) = YEARWEEK(CURDATE(), 1)",
  monthly: "YEAR({f}) = YEAR(CURDATE()) AND MONTH({f}) = MONTH(CURDATE())",
};

export const getReports = async (req, res) => {
  try {
    const period = req.query.period || "daily";
    const clause = (ranges[period] || ranges.daily).replace(/{f}/g, "transaction_date");
    const products = await query("SELECT * FROM products");
    const warehouses = await query("SELECT * FROM warehouses");
    const stockIn = await query(`SELECT * FROM stock_transactions WHERE transaction_type = 'IN' AND ${clause}`);
    const stockOut = await query(`SELECT * FROM stock_transactions WHERE transaction_type = 'OUT' AND ${clause}`);
    return res.json({ period, reports: { products, warehouses, stockIn, stockOut } });
  } catch {
    return res.status(500).json({ message: "Failed to generate reports." });
  }
};